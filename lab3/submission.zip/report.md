# Lab 3 Report — RRT Narrow-Gap Tuning

**Name:**

## Task 1 — Two-joint narrow gap (plots only)

1. Briefly explain each parameter below. Feel free to use external resources to help you understand the parameters.
- `RRT2D_STEP_SIZE` RRT2D_STEP_SIZE is what finds the distance between the current and previous itteration.
- `RRT2D_GOAL_BIAS` RRT2D_GOAL_BIAS is the parameter that finds the balance between random sampling so that the trajectory is able to reach the final destination and is what influences the magnetiude of the goal bias.
- `RRT2D_VALIDATION_DISTANCE` RRT2D_VALIDATION_DISTANCE is the resolution of the step size that is between collision checks.
- `RRT2D_MAX_ITERATIONS` RRT2D_MAX_ITERATIONS is the maximum amount of samples that the RRT performs with given parameters.
- `RRT2D_SEED` RRT2D_SEED is the random sampling path that is followed by the program when exploring various different paths.

2. Which settings solved the gap and passed the fine check? Explain what you changed and why.
The settings that solved the gap and passed the fine check were the step size, goal bias, validation distance, and max iterations. Reducing the step size from the default settings was beneficial as the original distance was less than the established value, because of this, the program for the arm was not able to take smaller steps to navigate it through a tight setting. Due to that the max iterations needed to be increased in order to account for the decrease in the step size. The second parameter that was changed was the goal bias. The goal bias was changed so that the probability that the random samples would find the 


## Task 2 — UR5 narrow gap (Swift)


| Parameter changed | Value | Complete RRT path found? | Fine check passed? | Planning time (s) | What did you observe? |
|-------------------|------:|:------------------------:|:------------------:|------------------:|-----------------------|
| Starter settings  |       |                          |                    |                   |                       |
|                   |       |                          |                    |                   |                       |
|                   |       |                          |                    |                   |                       |

1. Briefly explain the parameter(s) you changed and why. 
2. How did the lessons from Task 1 transfer to the UR5? 
3. What trade-offs did you observe between planning time and path quality? 

